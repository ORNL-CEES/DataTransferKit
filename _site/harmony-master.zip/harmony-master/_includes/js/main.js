jQuery(document).ready(function($){
    // todo: jquery stuff should need to put here.
});
