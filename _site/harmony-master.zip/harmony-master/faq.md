---
layout: page
title: Help / FAQ
---

What is harmony?
: Harmony is a free jekyll theme, for bloggers who love jekyll. Designed and build by [Gayan Virajith](http://gayanvirajith.github.io) & [Maheshika Lakmali](http://maheshikalakmali.github.io). 

Why are you doing this?
: For experience! Free resources are always good way to learn what you love, also help us to produce good digital work and it might end up being useful to someone.

Well, still have something in your mind?
: Please drop a line to [gayanvirajith@gmail.com](gayanvirajith@gmail.com) or an [issue](https://github.com/gayanvirajith/harmony/issues/new) on Github, I am glad to response.

